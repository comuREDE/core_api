<?php

DEFINE ('USER', 'web');
DEFINE ('HOST', 'localhost');
DEFINE ('NAME', 'comurede');
DEFINE ('PASS', '123');
############################################
DEFINE ('GMAIL', 'voipgus@gmail.com');
DEFINE ('SENHA', '123');

