<?php

function curl(string $url, string $method = 'GET', $headers = null, $body = null) {
    $ch = curl_init();
    if (!$headers)
        $headers = [];
    elseif (is_array ($headers)) {
        $tmp = $headers;
        $headers = [];
        foreach ($tmp as $key => $value)
            $headers[] = $key . ': ' . $value;
    }

    curl_setopt ($ch, CURLOPT_URL, $url);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt ($ch, CURLOPT_ENCODING, '');
    if ($method == 'GET') {
        curl_setopt ($ch, CURLOPT_HTTPGET, true);
    } elseif ($method == 'POST') {
        curl_setopt ($ch, CURLOPT_POST, true);
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $body);
    } elseif ($method == 'PUT') {
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		#curl_setopt($ch, CURLOPT_PUT, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$headers[] = 'X-HTTP-Method-Override: PUT';

    } elseif ($method == 'DELETE') {
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$headers[] = 'X-HTTP-Method-Override: DELETE';

    }

    if ($headers)
        curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers);

    curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt ($ch, CURLOPT_FAILONERROR, false);
    $response_headers = [];

    curl_setopt ($ch, CURLOPT_HEADERFUNCTION,
        function ($curl, $header) use (&$response_headers) {
            $length = strlen ($header);
            $header = explode (':', $header, 2);
            if (count ($header) < 2) #ignore invalid headers
                return $length;
            $name = strtolower (trim ($header[0]));
            if (!array_key_exists ($name, $response_headers))
                $response_headers[$name] = [trim ($header[1])];
            else
                $response_headers[$name][] = trim ($header[1]);
            return $length;
        }
    );

    if (!empty($ch_options))
        curl_setopt_array ($ch, $ch_options);

    $result = curl_exec ($ch);

    #print_r($result);
    $http_code = curl_getinfo ($ch, CURLINFO_HTTP_CODE);
    $curl_errno = curl_errno ($ch);
    $curl_error = curl_error ($ch);

    curl_reset ($ch);
    return json_decode($result, true);
    if($http_code==200 && gettype ($result) == 'string' && strlen ($result) > 1){
        return json_decode($result, true);
    } else {
        switch ($http_code) {
            case 429: $erro="Muitas requisicoes, aguarde um pouco";break;
            case 404: $erro="Pagina nao encontrada";break;
            case 500: $erro="Erro no servidor da corretora";break;
            default:  $erro="diferente de 200 = nao acessou o book";break;

        }
        echo "ERRO retorno $http_code ($erro) - $url<br>\n";
        return;
    }   
}