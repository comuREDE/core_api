<?php
require '_header.php';

$param = $_GET['param'];
switch ($param) {
	case 'estado_agua_agora':
		$sql="SELECT * FROM sensores_agua ORDER BY dia_hora DESC LIMIT 1;";
		$res = (new BD())->query($sql);

		echo "<pre>";
		print_r($res[0]);
		extract($res[0]);

		echo $estado==="D"? "<img src='imagens/vermelho_200x200.png'>":"<img src='imagens/azul_200x200.png'>";
	break;
	
	case 'estado_agua_agora_com_grafico':
		$sql="SELECT * FROM sensores_agua;";
		$res = (new BD())->query($sql);
		$json = json_encode($res,true);

		echo "<pre>";
		print_r($json);

	break;	

	default:
		echo "Informe um parametro";
	break;
}

