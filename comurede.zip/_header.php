﻿<?php

require("init.php");
require("pdo.php");
require("functions.php");
require("phpMQTT.php");

$titulo = $titulo ?? "Comurede";

