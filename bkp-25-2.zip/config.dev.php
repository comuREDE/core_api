<?php

DEFINE ('USER', 'web');
DEFINE ('HOST', 'localhost');
DEFINE ('NAME', 'comurede');
DEFINE ('PASS', '123');
############################################
DEFINE ('GMAIL', 'tacaindoagua@gmail.com');
DEFINE ('SENHA', 'Comux01$');

############################################
