<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Material Design Bootstrap</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body class="#7b1fa2 purple darken-2">


<div class="container ">
  
  <br>
  <!-- Card deck -->
  <div class="card-deck">

    <!-- Card -->
    <div class="card mb-4 #7b1fa2 purple darken-2">

      <!--Card image-->

        <h4 class="card-title text-default ">Ta caindo agua</h4>
      
      <div class="card-body #7b1fa2 purple darken-2 text-center">
       
        <img src="Icone-Lampada.svg">
      </div>
<!--       <i class="fas fa-tint fa-8x text-center text-info"></i>
 -->      <!--Card content-->
      <div class="card-body #e1bee7 purple lighten-5">

        <!--Title-->
 
        <canvas id="lineChart"></canvas>

  
      </div>

      <div class="card-footer">
        <!-- Default auto-sizing form -->
        <form>
          <!-- Grid row -->
          <div class="form-row align-items-center">


            <!-- Grid column -->
            <div class="col-auto">
              <!-- Default input -->
              <label class="sr-only" for="inlineFormInputGroup">Username</label>
              <div class="input-group mb-2">
                <div class="input-group-prepend">
                  <div class="input-group-text"><i class="fas fa-envelope text-secondary"></i></div>
                </div>
                <input type="text" class="form-control py-0" id="inlineFormInputGroup" placeholder="Username">
              </div>

              <button type="submit" class="btn btn-primary btn-md mt-0">Submit</button>
            </div>
          </div>
          <!-- Grid row -->
        </form>
        <!-- Default auto-sizing form -->        

      </div>  

    </div>
    <!-- Card -->

    <!-- Card -->
    <div class="card mb-4">

        <h4 class="card-title">Ta caindo ee</h4>
      <i class="fas fa-lightbulb fa-8x text-center text-secondary"></i>
      <!--Card content-->
      <div class="card-body">


        <!--Title-->
        <canvas id="lineChart2"></canvas>

        <button type="button" class="btn btn-light-blue btn-md">Read more</button>

      </div>

    </div>
    <!-- Card -->

  </div>
  <!-- Card deck -->

</div>








  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>

<script>
  //line
  var ctxL2 = document.getElementById("lineChart2").getContext('2d');
  var myLineChart2 = new Chart(ctxL2, {
    type: 'line',
    data: {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [{
          label: "My First dataset",
          data: [65, 59, 80, 81, 56, 55, 40],
          backgroundColor: [
            'rgba(105, 0, 132, .2)',
          ],
          borderColor: [
            'rgba(200, 99, 132, .7)',
          ],
          borderWidth: 2
        },
        {
          label: "My Second dataset",
          data: [28, 48, 40, 19, 86, 27, 90],
          backgroundColor: [
            'rgba(0, 137, 132, .2)',
          ],
          borderColor: [
            'rgba(0, 10, 130, .7)',
          ],
          borderWidth: 2
        }
      ]
    },
    options: {
      responsive: true
    }
  });  
  var ctxL = document.getElementById("lineChart").getContext('2d');
  var myLineChart = new Chart(ctxL, {
    type: 'line',
    data: {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [{
          label: "My First dataset",
          data: [65, 59, 80, 81, 56, 55, 40],
          backgroundColor: [
            'rgba(105, 0, 132, .2)',
          ],
          borderColor: [
            'rgba(200, 99, 132, .7)',
          ],
          borderWidth: 2
        },
        {
          label: "My Second dataset",
          data: [28, 48, 40, 19, 86, 27, 90],
          backgroundColor: [
            'rgba(0, 137, 132, .2)',
          ],
          borderColor: [
            'rgba(0, 10, 130, .7)',
          ],
          borderWidth: 2
        }
      ]
    },
    options: {
      responsive: true
    }
  });

</script>

</body>

</html>
