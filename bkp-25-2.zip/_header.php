﻿<?php

#require("init.php");
@require 'config.dev.php';
require("pdo.php");
require("phpMQTT.php");

$titulo = $titulo ?? "Comurede";

